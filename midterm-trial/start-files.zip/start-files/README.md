# Starter files for the midterm trial.

```
+ timer
| + index.html
| + script.js
| + style.css
+ my_notes_css
| + index.html
| + style.css
+ todolist
| + index.html
| + style.css
| + data.js
| + todos.js
```