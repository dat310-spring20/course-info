Vue.component('big-note',{
    // create the big-note component here
});