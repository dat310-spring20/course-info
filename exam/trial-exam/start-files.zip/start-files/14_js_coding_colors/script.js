/*
Exercise 14: JS coding
*/


function addBox(){
    // TODO: add a <div> with class "box" to the boxes.
    // add event handlers to this box.
}

function allBlue(){
    // TODO: change the color of all boxes to blue.
}


function init(){
    // this function is run on load. 
    // TODO: add eventlistener to the box, that changes color on click.
    // TODO: add eventlistener to the box, that remove box on double-click.
}

window.onload = init;